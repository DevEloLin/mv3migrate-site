import path from 'node:path'
import { ensureDir, pathExists, writeJson, writeText } from './lib.js'
import { scanExtension } from './scan.js'
import { renderReport, renderBatchReport } from './report.js'
import { buildPremiumSuggestions } from './premium.js'
import { copyExtensionTree } from './process.js'
import { generatePatch } from './patch.js'

export async function runBatch(inputs, { outDir, scanOnly, emitDnr, emitPatch }) {
  const entries = []
  const batchPatchChunks = []

  for (const inputDir of inputs) {
    const resolvedInputDir = path.resolve(inputDir)
    if (!(await pathExists(resolvedInputDir))) {
      throw new Error(`Input directory not found: ${resolvedInputDir}`)
    }

    const scanResult = await scanExtension(resolvedInputDir)
    const name = path.basename(resolvedInputDir)
    const targetDir = path.join(outDir, name)
    await ensureDir(targetDir)
    await copyExtensionTree(resolvedInputDir, targetDir, {
      manifest: scanResult.manifestResult.manifest,
      scanOnly,
    })
    const premium = emitDnr ? buildPremiumSuggestions(scanResult) : null
    const report = renderReport({
      inputDir: resolvedInputDir,
      manifestResult: scanResult.manifestResult,
      fileFindings: scanResult.fileFindings,
      changes: scanResult.manifestResult.changes,
      warnings: scanResult.manifestResult.warnings,
      premium,
    })
    await writeText(path.join(targetDir, 'mv3migrate-report.html'), report.html)
    if (emitDnr) {
      await writeJson(path.join(targetDir, 'mv3migrate-premium.json'), premium)
    }
    let patchPath = null
    if (emitPatch) {
      const patch = await generatePatch({
        inputDir: resolvedInputDir,
        outDir: targetDir,
        reportPath: path.join(targetDir, 'mv3migrate-report.html'),
        premiumPath: emitDnr ? path.join(targetDir, 'mv3migrate-premium.json') : null,
      })
      patchPath = path.join(targetDir, 'mv3migrate.patch')
      await writeText(patchPath, patch.patch)
      batchPatchChunks.push(`### ${path.basename(resolvedInputDir)}\n\n${patch.patch}`)
    }
    entries.push({
      inputDir: resolvedInputDir,
      outDir: targetDir,
      summary: report.summary,
      manifestChanges: scanResult.manifestResult.changes,
      manifestWarnings: scanResult.manifestResult.warnings,
      fileFindings: scanResult.fileFindings,
      premium,
      patchPath,
      scanOnly,
    })
  }

  return {
    entries,
    patchPath: emitPatch ? path.join(outDir, 'mv3migrate-batch.patch') : null,
    batchPatch: emitPatch ? `# mv3migrate batch patch\n\n${batchPatchChunks.join('\n\n')}\n` : null,
    summaryHtml: renderBatchReport(entries).html,
  }
}
