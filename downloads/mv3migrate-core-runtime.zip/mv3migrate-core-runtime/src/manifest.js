import { deepClone, unique } from './lib.js'

const HOST_PATTERN = /^(http|https|file|ftp|\*):\/\//
const BLOCKING_PERMISSIONS = new Set(['webRequest', 'webRequestBlocking'])

export function transformManifest(inputManifest) {
  const manifest = deepClone(inputManifest)
  const warnings = []
  const changes = []

  const output = deepClone(manifest)
  output.manifest_version = 3

  if (manifest.browser_action || manifest.page_action) {
    output.action = {
      ...(manifest.browser_action ?? {}),
      ...(manifest.page_action ?? {}),
    }
    delete output.browser_action
    delete output.page_action
    changes.push('browser_action/page_action -> action')
  }

  if (manifest.background?.scripts?.length) {
    output.background = {
      service_worker: 'background.js',
      type: 'module',
    }
    warnings.push('background.scripts requires a service worker rewrite')
    changes.push('background.scripts -> background.service_worker')
  }

  if (Array.isArray(manifest.permissions)) {
    const nextPermissions = []
    const hostPermissions = []

    for (const permission of manifest.permissions) {
      if (BLOCKING_PERMISSIONS.has(permission)) {
        warnings.push(`removed permission: ${permission} -> use declarativeNetRequest`)
        continue
      }
      if (HOST_PATTERN.test(permission)) {
        hostPermissions.push(permission)
        continue
      }
      nextPermissions.push(permission)
    }

    output.permissions = unique(nextPermissions)
    if (hostPermissions.length) {
      output.host_permissions = unique([...(manifest.host_permissions ?? []), ...hostPermissions])
      changes.push('host permissions moved to host_permissions')
    }
    if (manifest.permissions.some((permission) => BLOCKING_PERMISSIONS.has(permission))) {
      changes.push('blocking webRequest permissions removed')
    }
  }

  if (Array.isArray(manifest.web_accessible_resources)) {
    output.web_accessible_resources = [
      {
        resources: manifest.web_accessible_resources,
        matches: ['<all_urls>'],
      },
    ]
    warnings.push('web_accessible_resources converted to MV3 object form; review matches')
    changes.push('web_accessible_resources array -> object')
  }

  if (typeof manifest.content_security_policy === 'string') {
    output.content_security_policy = {
      extension_pages: manifest.content_security_policy,
    }
    if (/https?:\/\//.test(manifest.content_security_policy)) {
      warnings.push('content_security_policy references remote URLs; MV3 forbids remote hosted code')
    }
    changes.push('content_security_policy string -> object')
  }

  if (manifest.icons) output.icons = deepClone(manifest.icons)
  if (manifest.default_locale) output.default_locale = manifest.default_locale
  if (manifest.content_scripts) output.content_scripts = deepClone(manifest.content_scripts)

  return { manifest: output, warnings, changes }
}

