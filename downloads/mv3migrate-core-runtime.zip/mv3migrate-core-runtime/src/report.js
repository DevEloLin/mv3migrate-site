import path from 'node:path'
import { escapeHtml, relativeTo } from './lib.js'

function severityRank(severity) {
  if (severity === 'critical') return 3
  if (severity === 'warning') return 2
  return 1
}

export function renderReport({ inputDir, manifestResult, fileFindings, changes, warnings, premium }) {
  const rows = []
  for (const fileEntry of fileFindings) {
    for (const finding of fileEntry.findings) {
      rows.push({
        file: relativeTo(inputDir, fileEntry.path),
        severity: finding.severity,
        code: finding.code,
        message: finding.message,
      })
    }
  }

  rows.sort((a, b) => severityRank(b.severity) - severityRank(a.severity) || a.file.localeCompare(b.file))

  const summary = {
    critical: rows.filter((row) => row.severity === 'critical').length,
    warning: rows.filter((row) => row.severity === 'warning').length,
    info: rows.filter((row) => row.severity === 'info').length,
  }

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>mv3migrate report</title>
  <style>
    body { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif; margin: 0 auto; max-width: 960px; padding: 32px 20px 64px; line-height: 1.6; color: #111827; background: #fff; }
    h1, h2, h3 { line-height: 1.2; }
    .muted { color: #6b7280; }
    .pill { display:inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; margin-right: 8px; }
    .critical { background: #fee2e2; color: #991b1b; }
    .warning { background: #fef3c7; color: #92400e; }
    .info { background: #dbeafe; color: #1d4ed8; }
    table { width:100%; border-collapse: collapse; margin-top: 16px; }
    th, td { text-align:left; border-bottom: 1px solid #e5e7eb; padding: 10px 8px; vertical-align: top; }
    code { background:#f3f4f6; padding:2px 4px; border-radius: 4px; }
    pre { background:#f9fafb; border:1px solid #e5e7eb; padding:16px; overflow:auto; }
  </style>
</head>
<body>
  <h1>mv3migrate Migration Report</h1>
  <p class="muted">Input: ${escapeHtml(path.resolve(inputDir))}</p>

  <h2>Summary</h2>
  <p>
    <span class="pill critical">critical: ${summary.critical}</span>
    <span class="pill warning">warning: ${summary.warning}</span>
    <span class="pill info">info: ${summary.info}</span>
  </p>

  <h2>Manifest changes</h2>
  <ul>
    ${changes.length ? changes.map((change) => `<li>${escapeHtml(change)}</li>`).join('\n') : '<li>No manifest changes detected.</li>'}
  </ul>

  <h2>Manifest warnings</h2>
  <ul>
    ${warnings.length ? warnings.map((warning) => `<li>${escapeHtml(warning)}</li>`).join('\n') : '<li>No manifest warnings.</li>'}
  </ul>

  <h2>Findings</h2>
  <table>
    <thead>
      <tr><th>File</th><th>Severity</th><th>Code</th><th>Message</th></tr>
    </thead>
    <tbody>
      ${rows.length ? rows.map((row) => `<tr><td><code>${escapeHtml(row.file)}</code></td><td><span class="pill ${escapeHtml(row.severity)}">${escapeHtml(row.severity)}</span></td><td>${escapeHtml(row.code)}</td><td>${escapeHtml(row.message)}</td></tr>`).join('\n') : '<tr><td colspan="4">No issues found.</td></tr>'}
    </tbody>
  </table>

  <h2>Why this matters</h2>
  <p>The goal is not perfect automation. The goal is to reduce manual migration time and make the risky parts explicit.</p>

  ${
    premium?.dnr?.length
      ? `
  <h2>Premium suggestions</h2>
  ${premium.dnr
    .map(
      (item) => `
        <section>
          <h3>${escapeHtml(item.title)} <span class="pill critical">${escapeHtml(item.severity)}</span></h3>
          <p>${escapeHtml(item.recommendation)}</p>
          <ul>
            ${item.nextSteps.map((step) => `<li>${escapeHtml(step)}</li>`).join('\n')}
          </ul>
          ${
            item.draftRules?.length
              ? `<h4>Draft rules (${item.draftRules.length})</h4><pre>${escapeHtml(JSON.stringify(item.draftRules, null, 2))}</pre>`
              : ''
          }
          ${
            item.evidence?.length || item.draftRules?.some((rule) => rule.evidence)
              ? `<h4>Evidence</h4><pre>${escapeHtml(JSON.stringify(item.evidence?.length ? item.evidence : item.draftRules.map((rule) => rule.evidence).filter(Boolean), null, 2))}</pre>`
              : ''
          }
        </section>
      `,
    )
    .join('\n')}
      `
      : ''
  }
</body>
</html>`

  return { html, summary }
}

export function renderBatchReport(entries) {
  const totals = entries.reduce(
    (acc, entry) => {
      acc.critical += entry.summary.critical
      acc.warning += entry.summary.warning
      acc.info += entry.summary.info
      return acc
    },
    { critical: 0, warning: 0, info: 0 },
  )

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>mv3migrate batch report</title>
  <style>
    body { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif; margin: 0 auto; max-width: 1040px; padding: 32px 20px 64px; line-height: 1.6; color: #111827; background: #fff; }
    h1, h2, h3 { line-height: 1.2; }
    .muted { color: #6b7280; }
    .pill { display:inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; margin-right: 8px; }
    .critical { background: #fee2e2; color: #991b1b; }
    .warning { background: #fef3c7; color: #92400e; }
    .info { background: #dbeafe; color: #1d4ed8; }
    table { width:100%; border-collapse: collapse; margin-top: 16px; }
    th, td { text-align:left; border-bottom: 1px solid #e5e7eb; padding: 10px 8px; vertical-align: top; }
    code { background:#f3f4f6; padding:2px 4px; border-radius: 4px; }
  </style>
</head>
<body>
  <h1>mv3migrate Batch Report</h1>
  <p class="muted">Processed ${entries.length} extension folders.</p>
  <p>
    <span class="pill critical">critical: ${totals.critical}</span>
    <span class="pill warning">warning: ${totals.warning}</span>
    <span class="pill info">info: ${totals.info}</span>
  </p>

  <h2>Runs</h2>
  <table>
    <thead>
      <tr><th>Input</th><th>Critical</th><th>Warning</th><th>Info</th><th>Premium</th><th>Output</th></tr>
    </thead>
    <tbody>
      ${
        entries.length
          ? entries
              .map(
                (entry) =>
                  `<tr><td><code>${escapeHtml(path.basename(entry.inputDir))}</code></td><td>${entry.summary.critical}</td><td>${entry.summary.warning}</td><td>${entry.summary.info}</td><td>${entry.premium?.dnr?.length ?? 0}</td><td><code>${escapeHtml(relativeTo(process.cwd(), entry.outDir))}</code></td></tr>`,
              )
              .join('\n')
          : '<tr><td colspan="6">No entries.</td></tr>'
      }
    </tbody>
  </table>
</body>
</html>`

  return { html, summary: totals }
}
