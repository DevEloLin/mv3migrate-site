import path from 'node:path'
import { readJson, walkFiles } from './lib.js'
import { transformManifest } from './manifest.js'

const JS_EXTENSIONS = new Set(['.js', '.mjs', '.cjs', '.ts', '.tsx'])

export async function scanExtension(inputDir) {
  const files = await walkFiles(inputDir)
  const manifestPath = files.find((filePath) => path.basename(filePath) === 'manifest.json')
  if (!manifestPath) {
    throw new Error(`manifest.json not found in ${inputDir}`)
  }

  const manifest = await readJson(manifestPath)
  const manifestResult = transformManifest(manifest)
  const jsFiles = files.filter((filePath) => JS_EXTENSIONS.has(path.extname(filePath)))

  const fileFindings = []
  for (const filePath of jsFiles) {
    const source = await BunOrNodeRead(filePath)
    const findings = scanSource(source)
    if (findings.length) {
      fileFindings.push({ path: filePath, source, findings })
    }
  }

  return {
    manifestPath,
    manifest,
    manifestResult,
    jsFiles,
    fileFindings,
  }
}

async function BunOrNodeRead(filePath) {
  const fs = await import('node:fs/promises')
  return fs.readFile(filePath, 'utf8')
}

export function scanSource(source) {
  const findings = []

  if (/chrome\.browserAction\./.test(source)) findings.push({ severity: 'info', code: 'browserAction', message: 'browserAction API should move to chrome.action.' })
  if (/chrome\.pageAction\./.test(source)) findings.push({ severity: 'info', code: 'pageAction', message: 'pageAction API should move to chrome.action.' })
  if (/chrome\.tabs\.executeScript\s*\(/.test(source)) findings.push({ severity: 'info', code: 'executeScript', message: 'tabs.executeScript should move to chrome.scripting.executeScript.' })
  if (/chrome\.tabs\.insertCSS\s*\(/.test(source)) findings.push({ severity: 'info', code: 'insertCSS', message: 'tabs.insertCSS should move to chrome.scripting.insertCSS.' })
  if (/chrome\.(extension|runtime)\.getBackgroundPage\s*\(/.test(source)) findings.push({ severity: 'warning', code: 'getBackgroundPage', message: 'getBackgroundPage() is removed in MV3.' })
  if (/chrome\.webRequest\.(onBeforeRequest|onHeadersReceived|onAuthRequired|onBeforeSendHeaders)/.test(source)) findings.push({ severity: 'critical', code: 'webRequestBlocking', message: 'Blocking webRequest listeners need declarativeNetRequest.' })
  if (/\beval\s*\(/.test(source) || /new Function\s*\(/.test(source)) findings.push({ severity: 'warning', code: 'eval', message: 'eval/new Function needs review under MV3 security rules.' })

  return findings
}
