import fs from 'node:fs/promises'
import path from 'node:path'

export async function pathExists(filePath) {
  try {
    await fs.access(filePath)
    return true
  } catch {
    return false
  }
}

export async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, 'utf8'))
}

export async function writeJson(filePath, value) {
  await ensureDir(path.dirname(filePath))
  await fs.writeFile(filePath, JSON.stringify(value, null, 2) + '\n', 'utf8')
}

export async function writeText(filePath, value) {
  await ensureDir(path.dirname(filePath))
  await fs.writeFile(filePath, value, 'utf8')
}

export async function ensureDir(dirPath) {
  await fs.mkdir(dirPath, { recursive: true })
}

export async function walkFiles(rootDir) {
  const results = []
  async function visit(currentDir) {
    const entries = await fs.readdir(currentDir, { withFileTypes: true })
    for (const entry of entries) {
      const fullPath = path.join(currentDir, entry.name)
      if (entry.isDirectory()) {
        await visit(fullPath)
      } else {
        results.push(fullPath)
      }
    }
  }
  await visit(rootDir)
  return results
}

export function toPosix(filePath) {
  return filePath.split(path.sep).join('/')
}

export function unique(values) {
  return [...new Set(values)]
}

export function deepClone(value) {
  return structuredClone(value)
}

export function relativeTo(fromPath, toPath) {
  return toPosix(path.relative(fromPath, toPath))
}

export function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;')
}

