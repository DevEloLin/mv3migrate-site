import fs from 'node:fs/promises'
import { createPrivateKey, createPublicKey, sign, verify } from 'node:crypto'
import { resolvePlan } from './product.js'

export const DEFAULT_LICENSE_PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAu9WhWy2BxTAHvUremLHj0rXGhds/rGq8F0alT/ZphIE=
-----END PUBLIC KEY-----
`

const LICENSE_PREFIX = 'mv3migrate.'

function base64UrlEncode(input) {
  return Buffer.from(input).toString('base64url')
}

function base64UrlDecode(input) {
  return Buffer.from(input, 'base64url').toString('utf8')
}

function normalizePayload(payload) {
  return {
    customer: payload.customer ?? null,
    expiresAt: payload.expiresAt ?? null,
    issuedAt: payload.issuedAt ?? null,
    plan: resolvePlan(payload.plan),
    product: payload.product ?? 'mv3migrate',
    seats: payload.seats ?? 1,
  }
}

function canonicalPayloadString(payload) {
  return JSON.stringify(normalizePayload(payload))
}

export function createLicenseToken(payload, privateKeyPem) {
  const body = canonicalPayloadString(payload)
  const bodyPart = base64UrlEncode(body)
  const signature = sign(null, Buffer.from(body), createPrivateKey(privateKeyPem))
  const signaturePart = signature.toString('base64url')
  return `${LICENSE_PREFIX}${bodyPart}.${signaturePart}`
}

export function parseLicenseToken(token) {
  if (typeof token !== 'string' || !token.startsWith(LICENSE_PREFIX)) {
    throw new Error('License token must start with mv3migrate.')
  }

  const raw = token.slice(LICENSE_PREFIX.length)
  const parts = raw.split('.')
  if (parts.length !== 2) {
    throw new Error('License token format is invalid.')
  }

  const [bodyPart, signaturePart] = parts
  const body = base64UrlDecode(bodyPart)
  const payload = JSON.parse(body)
  return { body, payload, signature: Buffer.from(signaturePart, 'base64url') }
}

export async function loadLicensePublicKey(source) {
  if (!source) return DEFAULT_LICENSE_PUBLIC_KEY_PEM
  const file = await fs.readFile(source, 'utf8')
  return file.trim() + '\n'
}

export async function verifyLicenseToken(token, publicKeyPem = DEFAULT_LICENSE_PUBLIC_KEY_PEM) {
  const { body, payload, signature } = parseLicenseToken(token)
  const ok = verify(null, Buffer.from(body), createPublicKey(publicKeyPem), signature)
  if (!ok) {
    const error = new Error('License signature is invalid.')
    error.code = 'INVALID_LICENSE_SIGNATURE'
    throw error
  }

  if (payload.expiresAt && Date.now() > Date.parse(payload.expiresAt)) {
    const error = new Error('License has expired.')
    error.code = 'EXPIRED_LICENSE'
    throw error
  }

  return normalizePayload(payload)
}

