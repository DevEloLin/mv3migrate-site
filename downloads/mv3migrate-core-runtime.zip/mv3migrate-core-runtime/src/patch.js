import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { relativeTo, walkFiles } from './lib.js'

const execFileAsync = promisify(execFile)
const SOURCE_EXTENSIONS = new Set(['.json', '.js', '.mjs', '.cjs', '.ts', '.tsx'])

function isSourcePath(filePath) {
  return SOURCE_EXTENSIONS.has(path.extname(filePath)) || path.basename(filePath) === 'manifest.json'
}

async function readTextSafe(filePath) {
  try {
    return await (await import('node:fs/promises')).readFile(filePath, 'utf8')
  } catch {
    return null
  }
}

export async function generatePatch({ inputDir, outDir, reportPath, premiumPath }) {
  const inputFiles = await walkFiles(inputDir)
  const outFiles = await walkFiles(outDir)
  const patchChunks = []
  const changedFiles = []

  const relativePaths = new Set([
    ...inputFiles.map((filePath) => relativeTo(inputDir, filePath)),
    ...outFiles.map((filePath) => relativeTo(outDir, filePath)),
  ])

  for (const rel of [...relativePaths].sort()) {
    if (!isSourcePath(rel)) continue

    const inputFile = path.join(inputDir, rel)
    const outFile = path.join(outDir, rel)
    const [inputText, outText] = await Promise.all([readTextSafe(inputFile), readTextSafe(outFile)])
    if (inputText === outText) continue

    changedFiles.push(rel)
    const { stdout } = await execFileAsync(
      'git',
      ['diff', '--no-index', '--no-color', '--unified=3', '--', inputFile, outFile],
      { maxBuffer: 10 * 1024 * 1024 },
    ).catch((error) => ({
      stdout: error.stdout ?? '',
    }))
    patchChunks.push(stdout.trimEnd())
  }

  const metadata = {
    inputDir,
    outDir,
    reportPath: reportPath ?? null,
    premiumPath: premiumPath ?? null,
    changedFiles,
  }

  const fileList = changedFiles.length
    ? changedFiles.map((file) => `- ${file}`).join('\n')
    : '- none'
  const patch = `# mv3migrate patch
# metadata
# ${JSON.stringify(metadata, null, 2)}
#
# changed files (${changedFiles.length})
# ${fileList.replaceAll('\n', '\n# ')}

${patchChunks.filter(Boolean).join('\n\n')}
`
  return { patch, changedFiles, metadata }
}
