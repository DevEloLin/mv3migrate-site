import fs from 'node:fs/promises'
import path from 'node:path'
import { ensureDir, walkFiles, writeJson, writeText } from './lib.js'
import { transformJsSource } from './js-transform.js'

export async function copyExtensionTree(srcDir, dstDir, { manifest, scanOnly = false } = {}) {
  const files = await walkFiles(srcDir)
  for (const srcFile of files) {
    const rel = path.relative(srcDir, srcFile)
    const dstFile = path.join(dstDir, rel)
    const ext = path.extname(srcFile)

    if (ext === '.json') {
      const text = await fs.readFile(srcFile, 'utf8')
      if (path.basename(srcFile) === 'manifest.json' && manifest) {
        await writeJson(dstFile, manifest)
      } else {
        await writeText(dstFile, text)
      }
      continue
    }

    if (['.js', '.mjs', '.cjs', '.ts', '.tsx'].includes(ext) && !scanOnly) {
      const source = await fs.readFile(srcFile, 'utf8')
      const transformed = transformJsSource(source)
      await writeText(dstFile, transformed.source)
      continue
    }

    await ensureDir(path.dirname(dstFile))
    await fs.copyFile(srcFile, dstFile)
  }
}

