import { readFile, writeFile } from 'node:fs/promises'
import vm from 'node:vm'

function decodeStringLiteral(literal) {
  return vm.runInNewContext(`(${literal})`, {})
}

function splitTopLevelEntries(body) {
  const entries = []
  let current = ''
  let depth = 0
  let quote = null
  let escaped = false

  for (let index = 0; index < body.length; index += 1) {
    const char = body[index]

    if (quote) {
      current += char
      if (escaped) {
        escaped = false
      } else if (char === '\\') {
        escaped = true
      } else if (char === quote) {
        quote = null
      }
      continue
    }

    if (char === '"' || char === "'" || char === '`') {
      quote = char
      current += char
      continue
    }

    if (char === '(' || char === '[' || char === '{') depth += 1
    if (char === ')' || char === ']' || char === '}') depth -= 1

    if (char === ',' && depth === 0) {
      if (current.trim()) entries.push(current.trim())
      current = ''
      continue
    }

    current += char
  }

  if (current.trim()) entries.push(current.trim())
  return entries
}

function splitProperty(entry) {
  let depth = 0
  let quote = null
  let escaped = false

  for (let index = 0; index < entry.length; index += 1) {
    const char = entry[index]

    if (quote) {
      if (escaped) {
        escaped = false
      } else if (char === '\\') {
        escaped = true
      } else if (char === quote) {
        quote = null
      }
      continue
    }

    if (char === '"' || char === "'" || char === '`') {
      quote = char
      continue
    }

    if (char === '(' || char === '[' || char === '{') depth += 1
    if (char === ')' || char === ']' || char === '}') depth -= 1

    if (char === ':' && depth === 0) {
      const key = entry.slice(0, index).trim().replace(/^['"]|['"]$/g, '')
      const value = entry.slice(index + 1).trim()
      return { key, value }
    }
  }

  return null
}

function parseTopLevelObjectEntries(detailsBody) {
  const entries = new Map()
  for (const rawEntry of splitTopLevelEntries(detailsBody)) {
    const parsed = splitProperty(rawEntry)
    if (parsed?.key) entries.set(parsed.key, parsed.value)
  }
  return entries
}

function extractStringProperty(detailsBody, propertyName) {
  const pattern = new RegExp(`${propertyName}\\s*:\\s*(['"])([\\s\\S]*?)\\1`)
  const match = detailsBody.match(pattern)
  if (!match) return null
  const literal = `${match[1]}${match[2]}${match[1]}`
  return { value: decodeStringLiteral(literal) }
}

function buildExecuteScriptReplacement(tabIdExpr, detailsBody, warnings) {
  const entries = parseTopLevelObjectEntries(detailsBody)
  const codeProperty = extractStringProperty(detailsBody, 'code')
  const fileProperty = extractStringProperty(detailsBody, 'file')
  const targetExtras = []
  const scriptExtras = []

  if (codeProperty) {
    entries.delete('code')
    for (const [key, value] of entries.entries()) {
      if (['allFrames', 'frameIds', 'documentIds'].includes(key)) {
        targetExtras.push(`${key}: ${value}`)
      } else if (['args', 'world', 'injectImmediately'].includes(key)) {
        scriptExtras.push(`${key}: ${value}`)
      } else {
        warnings.push(`executeScript details contain unsupported property: ${key}`)
      }
    }
    const targetBody = [`tabId: ${tabIdExpr.trim()}`, ...targetExtras].join(', ')
    const scriptBody = [`func: () => { ${codeProperty.value} }`, ...scriptExtras].join(', ')
    return `chrome.scripting.executeScript({ target: { ${targetBody} }, ${scriptBody} })`
  }

  if (fileProperty) {
    entries.delete('file')
    for (const [key, value] of entries.entries()) {
      if (['allFrames', 'frameIds', 'documentIds'].includes(key)) {
        targetExtras.push(`${key}: ${value}`)
      } else if (['args', 'world', 'injectImmediately'].includes(key)) {
        scriptExtras.push(`${key}: ${value}`)
      } else {
        warnings.push(`executeScript details contain unsupported property: ${key}`)
      }
    }
    const targetBody = [`tabId: ${tabIdExpr.trim()}`, ...targetExtras].join(', ')
    const scriptBody = [`files: [${JSON.stringify(fileProperty.value)}]`, ...scriptExtras].join(', ')
    return `chrome.scripting.executeScript({ target: { ${targetBody} }, ${scriptBody} })`
  }

  warnings.push('executeScript call was detected, but it was not rewritten because the details object is not a simple code/file form')
  return null
}

function buildInsertCssReplacement(tabIdExpr, detailsBody, warnings) {
  const entries = parseTopLevelObjectEntries(detailsBody)
  const codeProperty = extractStringProperty(detailsBody, 'code')
  const fileProperty = extractStringProperty(detailsBody, 'file')
  const targetExtras = []
  const cssExtras = []

  if (codeProperty) {
    entries.delete('code')
    for (const [key, value] of entries.entries()) {
      if (['allFrames', 'frameIds', 'documentIds'].includes(key)) {
        targetExtras.push(`${key}: ${value}`)
      } else if (['origin', 'injectImmediately'].includes(key)) {
        cssExtras.push(`${key}: ${value}`)
      } else {
        warnings.push(`insertCSS details contain unsupported property: ${key}`)
      }
    }
    const targetBody = [`tabId: ${tabIdExpr.trim()}`, ...targetExtras].join(', ')
    const cssBody = [`css: ${JSON.stringify(codeProperty.value)}`, ...cssExtras].join(', ')
    return `chrome.scripting.insertCSS({ target: { ${targetBody} }, ${cssBody} })`
  }

  if (fileProperty) {
    entries.delete('file')
    for (const [key, value] of entries.entries()) {
      if (['allFrames', 'frameIds', 'documentIds'].includes(key)) {
        targetExtras.push(`${key}: ${value}`)
      } else if (['origin', 'injectImmediately'].includes(key)) {
        cssExtras.push(`${key}: ${value}`)
      } else {
        warnings.push(`insertCSS details contain unsupported property: ${key}`)
      }
    }
    const targetBody = [`tabId: ${tabIdExpr.trim()}`, ...targetExtras].join(', ')
    const cssBody = [`files: [${JSON.stringify(fileProperty.value)}]`, ...cssExtras].join(', ')
    return `chrome.scripting.insertCSS({ target: { ${targetBody} }, ${cssBody} })`
  }

  warnings.push('insertCSS call was detected, but it was not rewritten because the details object is not a simple code/file form')
  return null
}

export function transformJsSource(source) {
  let code = source
  const warnings = []
  const changes = []

  const actionReplacements = [
    ['chrome.browserAction.', 'chrome.action.', 'browserAction -> action'],
    ['chrome.pageAction.', 'chrome.action.', 'pageAction -> action'],
  ]
  for (const [from, to, label] of actionReplacements) {
    if (code.includes(from)) {
      code = code.replaceAll(from, to)
      changes.push(label)
    }
  }

  code = code.replace(
    /chrome\.tabs\.executeScript\(\s*([^,]+?)\s*,\s*\{\s*([\s\S]*?)\s*\}\s*\)/g,
    (match, tabIdExpr, detailsBody) => {
      const replacement = buildExecuteScriptReplacement(tabIdExpr, detailsBody, warnings)
      if (replacement !== null) {
        changes.push('tabs.executeScript -> scripting.executeScript')
      }
      return replacement ?? match
    },
  )

  code = code.replace(
    /chrome\.tabs\.insertCSS\(\s*([^,]+?)\s*,\s*\{\s*([\s\S]*?)\s*\}\s*\)/g,
    (match, tabIdExpr, detailsBody) => {
      const replacement = buildInsertCssReplacement(tabIdExpr, detailsBody, warnings)
      if (replacement !== null) {
        changes.push('tabs.insertCSS -> scripting.insertCSS')
      }
      return replacement ?? match
    },
  )

  if (code.includes('chrome.runtime.getBackgroundPage(')) {
    code = code.replace(
      /chrome\.runtime\.getBackgroundPage\(\s*\)/g,
      '/* mv3migrate WARNING: runtime.getBackgroundPage() removed in MV3. Use chrome.runtime.sendMessage() */ null',
    )
    warnings.push('runtime.getBackgroundPage() removed in MV3; use messaging instead')
    changes.push('runtime.getBackgroundPage -> warning')
  }

  if (code.includes('chrome.extension.getBackgroundPage(')) {
    code = code.replace(
      /chrome\.extension\.getBackgroundPage\(\s*\)/g,
      '/* mv3migrate WARNING: getBackgroundPage() removed in MV3. Use chrome.runtime.sendMessage() */ null',
    )
    warnings.push('getBackgroundPage() removed in MV3; use messaging instead')
    changes.push('getBackgroundPage -> warning')
  }

  if (/\beval\s*\(/.test(code) || /new Function\s*\(/.test(code)) {
    warnings.push('eval/new Function detected; MV3 remote code restrictions apply')
  }

  return { source: code, warnings, changes }
}

export async function transformJsFile(filePath) {
  const input = await readFile(filePath, 'utf8')
  const result = transformJsSource(input)
  await writeFile(filePath, `${result.source.trimEnd()}\n`, 'utf8')
  return result
}
