# mv3migrate-core

Minimal Chrome MV2 -> MV3 migration CLI.

This prototype does three things:

1. Scans a Chrome extension for MV2-only APIs and risky patterns.
2. Rewrites a small but useful set of MV2 manifest and JS patterns.
3. Produces a human-readable HTML migration report.

The commercial boundary is explicit:

- Free: single-extension runs, manifest conversion, JS scan, HTML report.
- Pro: one-time purchase, batch runs, premium DNR suggestions, per-run premium JSON output, and patch export.

Questions: `mv3migrate@elolin.com`

## Customer flow

1. Buy Pro from the pricing page by email.
2. Receive a signed token by email.
3. Run the CLI locally against your extension folder.
4. Pass `--license` and `--license-public-key` to unlock Pro features.
5. Inspect the output directory, HTML report, and patch before shipping.

Example customer command:

```bash
mv3migrate ./my-extension \
  --out ./my-extension-mv3 \
  --report ./report.html \
  --emit-dnr \
  --emit-patch \
  --license "mv3migrate...." \
  --license-public-key ./keys/mv3migrate-public.pem
```

## Distribution model

This repository is the source tree for the CLI. End users do not need the whole
repo checkout to use the tool.

Recommended delivery options:

- Public npm package for installable CLI usage.
- GitHub release assets or a generated ZIP that contains only runtime files.

To create the runtime bundle locally:

```bash
./scripts/build-release.sh
```

That writes `release/mv3migrate-core-runtime.zip`.

The package metadata is already restricted to the runtime entrypoints, so build
artifacts will not include tests, fixtures, regression rosters, temporary
outputs, or local key material.

In other words:

- Keep the source repo separate for development.
- Publish a clean runtime package for users.
- Do not ship `tmp/`, `tests/`, `regressions/`, or `keys/*.pem` to customers.

## What it supports

- `manifest_version: 2 -> 3`
- `browser_action` / `page_action -> action`
- `background.scripts -> background.service_worker`
- `permissions` split into `permissions` and `host_permissions`
- `web_accessible_resources` conversion to MV3 object form
- `content_security_policy` string to MV3 object form
- `chrome.browserAction.* -> chrome.action.*`
- `chrome.pageAction.* -> chrome.action.*`
- `chrome.tabs.executeScript(...) -> chrome.scripting.executeScript(...)`
- `chrome.tabs.insertCSS(...) -> chrome.scripting.insertCSS(...)`
- `chrome.extension.getBackgroundPage()` / `chrome.runtime.getBackgroundPage()`
- `eval()` / `new Function()` detection
- Premium DNR draft generation for:
  - blocking listeners
  - redirect listeners
  - header mutation listeners

## Install

No runtime dependencies are required.

```bash
cd mv3migrate-core
node --version
```

## Quick Start

Run the free path on a sample fixture:

```bash
node ./src/cli.js ./tests/fixtures/simple-popup --out ./tmp/simple-popup-mv3 --report ./tmp/simple-popup-report.html
```

Run the paid path with a signed license token:

```bash
node ./src/cli.js ./tests/fixtures/webrequest-blocker \
  --out ./tmp/webrequest-mv3 \
  --report ./tmp/webrequest-report.html \
  --emit-dnr \
  --license "mv3migrate...." \
  --license-public-key ./keys/mv3migrate-public.pem
```

Issue a token manually from the shell:

```bash
./scripts/issue-license.sh \
  --customer "Acme Corp" \
  --plan pro \
  --seats 1 \
  --expires-at 2027-06-22T00:00:00.000Z
```

The generated keypair is stored in `./keys/` and kept out of git.

## Buying and delivery

The product is intentionally offline-first:

- The buyer does not create a SaaS account.
- The vendor issues a signed token after purchase.
- The CLI verifies the token locally with a public key.
- Free users can still run the manifest conversion and report path without a token.

## Usage

```bash
node ./src/cli.js <input-dir> [--out <out-dir>] [--report <report.html>] [--scan-only]
```

Paid flags:

- `--license <token>` to unlock the paid mode path with a signed license token
- `--license-public-key <path>` to test against a custom public key
- `--emit-dnr` to write premium `declarativeNetRequest` suggestions
- `--emit-patch` to write a review-ready patch file for the migrated tree

Internal testing only:

- `MV3MIGRATE_INTERNAL_PLAN_OVERRIDE=1` can be used with `--plan pro` to exercise legacy premium branches without a token.

Batch mode is paid:

```bash
node ./src/cli.js ./tests/fixtures/content-script-injector ./tests/fixtures/webrequest-blocker --out ./tmp/batch-mv3 --report ./tmp/batch-report.html --emit-dnr --license "mv3migrate...." --license-public-key ./keys/mv3migrate-public.pem
```

For internal testing only, you can still exercise the legacy premium branch:

```bash
MV3MIGRATE_INTERNAL_PLAN_OVERRIDE=1 node ./src/cli.js ./tests/fixtures/content-script-injector ./tests/fixtures/webrequest-blocker --out ./tmp/batch-mv3 --report ./tmp/batch-report.html --emit-dnr --plan pro
```

Patch export:

```bash
node ./src/cli.js ./tests/fixtures/webrequest-blocker --out ./tmp/patch-mv3 --report ./tmp/patch-report.html --emit-patch --license "mv3migrate...." --license-public-key ./keys/mv3migrate-public.pem
```

For internal testing only, you can still exercise the legacy premium branch:

```bash
MV3MIGRATE_INTERNAL_PLAN_OVERRIDE=1 node ./src/cli.js ./tests/fixtures/webrequest-blocker --out ./tmp/patch-mv3 --report ./tmp/patch-report.html --emit-patch --plan pro
```

License token format:

```text
mv3migrate.<base64url(payload)>.<base64url(signature)>
```

Payload fields:

- `plan`
- `customer`
- `issuedAt`
- `expiresAt`
- `seats`

The prototype verifies Ed25519 signatures locally. In production, the private key
would stay with the vendor; the CLI only ships the public key.

## Manual license issuing

If you want to email tokens by hand, mint them locally. The shell wrapper will
create a keypair in `./keys/` the first time it runs:

```bash
MV3MIGRATE_LICENSE_PRIVATE_KEY_PATH=./private.pem \
  npm run license:mint -- \
  --customer "Acme Corp" \
  --plan pro \
  --seats 1 \
  --expires-at 2027-06-22T00:00:00.000Z
```

You can also pass the PEM inline:

```bash
npm run license:mint -- \
  --customer "Acme Corp" \
  --plan pro \
  --private-key-inline "-----BEGIN PRIVATE KEY-----..."
```

You can also use the CLI subcommand:

```bash
node ./src/cli.js license mint \
  --customer "Acme Corp" \
  --plan pro \
  --private-key-inline "-----BEGIN PRIVATE KEY-----..."
```

For a full manual issuance flow with saved keys, use the shell wrapper:

```bash
./scripts/issue-license.sh \
  --customer "Acme Corp" \
  --plan pro \
  --seats 1 \
  --expires-at 2027-06-22T00:00:00.000Z
```

Examples:

```bash
node ./src/cli.js ./tests/fixtures/simple-popup --out ./tmp/simple-popup-mv3 --report ./tmp/simple-popup-report.html
node ./src/cli.js ./tests/fixtures/content-script-injector --out ./tmp/content-script-mv3 --report ./tmp/content-script-report.html
node ./src/cli.js ./tests/fixtures/webrequest-blocker --out ./tmp/webrequest-mv3 --report ./tmp/webrequest-report.html
```

## Output

- Transformed extension files are written to `--out`.
- The HTML report is written to `--report` or `<out>/mv3migrate-report.html`.
- The CLI prints a JSON summary to stdout.
- In paid mode, the CLI also writes `mv3migrate-premium.json` alongside the output.
- With `--emit-patch`, the CLI writes `mv3migrate.patch` alongside the output.

## Tests

```bash
node --test
```

Current test coverage is fixture-driven and includes:

- CLI free-path smoke on `simple-popup`
- manifest conversion and JS rewrites on `content-script-injector`
- blocking webRequest detection on `webrequest-blocker`
- redirect DNR drafts on `webrequest-redirector`
- header-modification DNR drafts on `webrequest-header-modifier`
- append-aware header DNR drafts on `webrequest-header-append`
- mixed listener DNR generation on `webrequest-mixed`
- rejection of free-plan premium access
- rejection of legacy `--plan pro` without a token
- internal override path for local testing
- batch output and patch export
- signed token issuance and verification
- shell-based issue script
- manifest, scan, and transform unit tests

For a one-command end-to-end verification, use:

```bash
./scripts/manual-verify.sh all
```

For a matrix-style regression summary across the representative fixtures, use:

```bash
./scripts/regression-matrix.sh
```

For a larger roster that can include checked-out third-party MV2 repositories, use:

```bash
node ./scripts/run-regression-roster.mjs --roster ./regressions/roster.example.json
```

To fetch and run a curated set of public third-party MV2 extension repos, use:

```bash
./scripts/run-third-party-regressions.sh
```

The verified public third-party set is recorded in:

- `regressions/third-party-verified.json`

Current verified set:

- `isaacherrera47/chrome-extension-test`
- `repodevcode/Chrome-Extensions-Template--manifest-v2-`
- `nikunjjoshi04/chrome_extension_hello_world/manifest_version_2`
- `rohitsharmaj7/Chrome-Extensions/hello world`
- `AshHeskes/eval-extension/client`
- `iiteen/MYT`

Excluded sample:

- `yuvrajverma01/Instant_Profile_Access` because its manifest is not valid JSON.

For a branch/PR preparation flow, use:

```bash
./scripts/prepare-pr.sh --no-pr
```

## Fixtures

The repository includes ten fixtures:

- `simple-popup`
- `content-script-injector`
- `webrequest-blocker`
- `webrequest-redirector`
- `webrequest-header-modifier`
- `webrequest-header-append`
- `webrequest-mixed`
- `execute-script-advanced`
- `webrequest-multi-route`
- `csp-and-war`

They are used to validate the current MVP scope:

- safe manifest conversion
- DOM injection migration
- blocked webRequest migration warnings
- redirect DNR draft generation
- header-modification DNR draft generation
- append-aware header DNR draft generation
- mixed-listener DNR generation
- signed token issuance and paid unlock
- patch export and batch output
- executeScript / insertCSS rewrites with extra options
- evidence-rich DNR drafts for multi-route listeners
- CSP and web_accessible_resources conversion
- auto-PR preparation script
- regression matrix script
- regression roster support for third-party repo checkouts
- curated public third-party MV2 repos runner
- checked-in verification summary for third-party repos
- Chrome unpacked smoke validation

## Free vs Pro

Free:

- single input directory
- manifest conversion
- JS scan
- HTML report

Pro:

- batch runs
- DNR drafts
- premium JSON output
- patch export
- license token unlock

The intended commercial flow is:

1. User buys Pro.
2. You run `./scripts/issue-license.sh` or `npm run license:mint`.
3. You email the token to the buyer.
4. The buyer runs the CLI with `--license` and `--license-public-key`.

## Caveats

This is a migration assistant, not a full automatic port.

- Complex `chrome.tabs.executeScript` callbacks are not fully rewritten.
- Non-trivial `declarativeNetRequest` rule generation is best-effort and still needs review.
- Any rewrite that cannot be made safe is left as a warning for manual review.

## Chrome smoke test

The repository also includes a best-effort unpacked-extension smoke test:

```bash
node ./scripts/chrome-load-unpacked.mjs --extension ./tmp/simple-popup-mv3 --headed
```

It starts Google Chrome with `--load-extension`, waits for unpacked extension targets, and then tries to read the browser profile record as a secondary signal. Some managed Chrome installs can interfere with the profile record, so treat this as a smoke test with a fallback target check rather than a GUI automation replacement. `--headed` is the recommended mode for this validation.

For a stricter local run, provide a clean profile directory and keep it for inspection:

```bash
MV3MIGRATE_CHROME_PROFILE_DIR=/tmp/mv3migrate-clean-profile \
  node ./scripts/chrome-load-unpacked.mjs \
  --extension ./tmp/simple-popup-mv3 \
  --headed \
  --require-preferences \
  --keep-profile
```

For CI-style diagnostics, the workflow uses the same script with an explicit profile
directory and uploads the resulting smoke artifacts if the check fails.

## Quality gates

The repository now includes two CI entry points:

- `mv3migrate-quality-gate.yml` for tests, regression matrix, roster checks, and Chrome smoke.
- `mv3migrate-auto-pr.yml` for verifying a branch and opening a PR from that branch.

Both workflows live under `.github/workflows/` in the `saas-web-dev` repository.

## Pricing intent

The value boundary is based on time saved and risk reduced:

- Free covers a first-pass conversion for one extension folder.
- Pro covers repeatable work across multiple folders and high-signal migration advice.
- The product is intentionally narrow: one-time purchase, no SaaS account.
- Public contact: `mv3migrate@elolin.com`
