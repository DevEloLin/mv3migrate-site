#!/usr/bin/env node
import path from 'node:path'
import { ensureDir, pathExists, writeJson, writeText } from './lib.js'
import { scanExtension } from './scan.js'
import { renderReport } from './report.js'
import { assertPremium, resolvePlan } from './product.js'
import { buildPremiumSuggestions } from './premium.js'
import { runBatch } from './batch.js'
import { copyExtensionTree } from './process.js'
import { loadLicensePublicKey, verifyLicenseToken } from './license.js'
import { generatePatch } from './patch.js'
import { runLicenseMint } from './license-mint.js'

const INTERNAL_PLAN_OVERRIDE = process.env.MV3MIGRATE_INTERNAL_PLAN_OVERRIDE === '1'

function parseRunArgs(argv) {
  const args = {
    inputDirs: [],
    outDir: null,
    reportPath: null,
    scanOnly: false,
    emitDnr: false,
    emitPatch: false,
    plan: 'free',
    license: null,
    licensePublicKey: null,
  }

  const rest = [...argv]
  while (rest.length) {
    const value = rest.shift()
    if (value && !value.startsWith('-')) {
      args.inputDirs.push(value)
      continue
    }
    if (value === '--out') {
      args.outDir = rest.shift() ?? null
      continue
    }
    if (value === '--report') {
      args.reportPath = rest.shift() ?? null
      continue
    }
    if (value === '--scan-only') {
      args.scanOnly = true
      continue
    }
    if (value === '--emit-dnr') {
      args.emitDnr = true
      continue
    }
    if (value === '--emit-patch') {
      args.emitPatch = true
      continue
    }
    if (value === '--plan') {
      args.plan = rest.shift() ?? 'free'
      continue
    }
    if (value === '--license') {
      args.license = rest.shift() ?? null
      continue
    }
    if (value === '--license-public-key') {
      args.licensePublicKey = rest.shift() ?? null
      continue
    }
    if (value === '--help' || value === '-h') {
      args.help = true
    }
  }

  return args
}

function printUsage() {
  console.log(
    [
      'Usage:',
      '  mv3migrate [run] <input-dir> [<input-dir> ...] [--out <out-dir>] [--report <report.html>] [--scan-only] [--emit-dnr] [--emit-patch] [--license <token>] [--license-public-key <path>]',
      '  mv3migrate license mint --customer <name> [--plan pro] [--seats <n>] [--expires-at <iso>] [--private-key <path>]',
      '  mv3migrate --version',
      '  Contact: mv3migrate@elolin.com',
      '',
      'Free:',
      '  - single input directory',
      '  - manifest conversion',
      '  - JS scan',
      '  - HTML report',
      '',
      'Paid:',
      '  - multiple input directories in one run',
      '  - batch summary',
      '  - DNR suggestions for blocking webRequest migrations',
      '  - requires a signed license token',
      '',
      'Internal testing only:',
      '  - MV3MIGRATE_INTERNAL_PLAN_OVERRIDE=1 enables the legacy --plan pro override',
    ].join('\n'),
  )
}

function splitTopLevelCommand(argv) {
  const [first, second, ...rest] = argv
  if (first === '--version' || first === '-v') {
    return { command: 'version', argv: [] }
  }
  if (!first || first.startsWith('-')) {
    return { command: 'run', argv }
  }
  if (first === 'run') {
    return { command: 'run', argv: [second, ...rest].filter((value) => value !== undefined) }
  }
  if (first === 'license' && (second === 'mint' || second === 'issue')) {
    return { command: 'license-mint', argv: rest }
  }
  if (first === 'mint-license' || first === 'license-mint') {
    return { command: 'license-mint', argv: [second, ...rest].filter((value) => value !== undefined) }
  }
  return { command: 'run', argv }
}

async function runMigration(argv) {
  const args = parseRunArgs(argv)
  let plan = resolvePlan(args.plan)
  if (args.license) {
    const publicKeyPem = await loadLicensePublicKey(args.licensePublicKey ?? process.env.MV3MIGRATE_LICENSE_PUBLIC_KEY)
    const license = await verifyLicenseToken(args.license, publicKeyPem)
    plan = license.plan
    args.licenseInfo = license
  } else if (plan === 'pro' && !INTERNAL_PLAN_OVERRIDE) {
    const error = new Error(
      'Paid features require a signed license token. Use --license, or set MV3MIGRATE_INTERNAL_PLAN_OVERRIDE=1 for internal testing.',
    )
    error.code = 'LICENSE_REQUIRED'
    throw error
  }
  args.plan = plan

  if (args.help) {
    printUsage()
    process.exit(0)
  }

  if (!args.inputDirs.length) {
    printUsage()
    process.exit(1)
  }

  const outDir = args.outDir ? path.resolve(args.outDir) : path.join(process.cwd(), 'mv3migrate-out')
  await ensureDir(outDir)

  if (args.inputDirs.length > 1) {
    assertPremium(args.plan, 'Batch migration')
    const batch = await runBatch(args.inputDirs, {
      outDir,
      scanOnly: args.scanOnly,
      emitDnr: args.emitDnr,
      emitPatch: args.emitPatch,
    })
    const reportPath = args.reportPath ? path.resolve(args.reportPath) : path.join(outDir, 'mv3migrate-batch-report.html')
    await writeText(reportPath, batch.summaryHtml)
    if (args.emitPatch) {
      assertPremium(args.plan, 'Patch export')
      const batchPatchPath = batch.patchPath ?? path.join(outDir, 'mv3migrate-batch.patch')
      await writeText(batchPatchPath, batch.batchPatch ?? '')
    }
    console.log(
      JSON.stringify(
        {
          plan: args.plan,
          license: args.licenseInfo ?? null,
          batch: true,
          outDir,
          reportPath,
          patchPath: batch.patchPath ?? null,
          batchPatchPath: batch.patchPath ?? null,
          entries: batch.entries,
        },
        null,
        2,
      ),
    )
    return
  }

  const inputDir = path.resolve(args.inputDirs[0])
  if (!(await pathExists(inputDir))) {
    throw new Error(`Input directory not found: ${inputDir}`)
  }

  const scanResult = await scanExtension(inputDir)
  const premium = args.emitDnr ? buildPremiumSuggestions(scanResult) : null
  await copyExtensionTree(inputDir, outDir, { manifest: scanResult.manifestResult.manifest, scanOnly: args.scanOnly })

  const report = renderReport({
    inputDir,
    manifestResult: scanResult.manifestResult,
    fileFindings: scanResult.fileFindings,
    changes: scanResult.manifestResult.changes,
    warnings: scanResult.manifestResult.warnings,
    premium,
  })

  const reportPath = args.reportPath ? path.resolve(args.reportPath) : path.join(outDir, 'mv3migrate-report.html')
  await writeText(reportPath, report.html)

  if (args.emitDnr) {
    assertPremium(args.plan, 'DNR suggestions')
    await writeJson(path.join(outDir, 'mv3migrate-premium.json'), premium)
  }

  let patchPath = null
  if (args.emitPatch) {
    assertPremium(args.plan, 'Patch export')
    const patch = await generatePatch({
      inputDir,
      outDir,
      reportPath,
      premiumPath: args.emitDnr ? path.join(outDir, 'mv3migrate-premium.json') : null,
    })
    patchPath = path.join(outDir, 'mv3migrate.patch')
    await writeText(patchPath, patch.patch)
  }

  const summary = {
    plan: args.plan,
    license: args.licenseInfo ?? null,
    inputDir,
    outDir,
    reportPath,
    patchPath,
    manifestChanges: scanResult.manifestResult.changes,
    manifestWarnings: scanResult.manifestResult.warnings,
    fileFindings: scanResult.fileFindings,
    premium,
    summary: report.summary,
  }

  console.log(JSON.stringify(summary, null, 2))
  return summary
}

async function main() {
  const { command, argv } = splitTopLevelCommand(process.argv.slice(2))
  if (command === 'version') {
    console.log('0.8.0')
    return
  }
  if (command === 'license-mint') {
    const result = await runLicenseMint(argv)
    if (result && !result.ok) process.exit(result.exitCode ?? 1)
    return
  }
  const args = argv
  if (!args.length) {
    printUsage()
    process.exit(1)
  }
  await runMigration(args)
}

main().catch((error) => {
  console.error(error.stack || error.message)
  process.exit(1)
})
