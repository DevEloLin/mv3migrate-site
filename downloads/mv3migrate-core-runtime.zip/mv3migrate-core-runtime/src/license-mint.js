#!/usr/bin/env node
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createLicenseToken } from './license.js'
import { resolvePlan } from './product.js'

export function parseMintArgs(argv) {
  const args = {
    customer: null,
    plan: 'pro',
    issuedAt: new Date().toISOString(),
    expiresAt: null,
    seats: 1,
    product: 'mv3migrate',
    privateKey: null,
    privateKeyPath: null,
    out: null,
  }

  const rest = [...argv]
  while (rest.length) {
    const value = rest.shift()
    if (value === '--customer') {
      args.customer = rest.shift() ?? null
      continue
    }
    if (value === '--plan') {
      args.plan = rest.shift() ?? 'pro'
      continue
    }
    if (value === '--issued-at') {
      args.issuedAt = rest.shift() ?? args.issuedAt
      continue
    }
    if (value === '--expires-at') {
      args.expiresAt = rest.shift() ?? null
      continue
    }
    if (value === '--seats') {
      const seats = Number(rest.shift() ?? '1')
      args.seats = Number.isFinite(seats) && seats > 0 ? Math.floor(seats) : 1
      continue
    }
    if (value === '--product') {
      args.product = rest.shift() ?? 'mv3migrate'
      continue
    }
    if (value === '--private-key') {
      args.privateKeyPath = rest.shift() ?? null
      continue
    }
    if (value === '--private-key-inline') {
      args.privateKey = rest.shift() ?? null
      continue
    }
    if (value === '--out') {
      args.out = rest.shift() ?? null
      continue
    }
    if (value === '--help' || value === '-h') {
      args.help = true
    }
  }

  return args
}

function printUsage() {
  console.log(
    [
      'Usage: mv3migrate license mint --customer <name> [--plan pro] [--issued-at <iso>] [--expires-at <iso>] [--seats <n>] [--product mv3migrate] [--private-key <path> | --private-key-inline <pem>] [--out <file>]',
      'Alias: npm run license:mint -- [options]',
      '',
      'Defaults:',
      '  - plan: pro',
      '  - seats: 1',
      '  - product: mv3migrate',
      '  - issued-at: now',
      '',
      'Private key sources:',
      '  - --private-key <path>',
      '  - --private-key-inline <pem>',
      '  - MV3MIGRATE_LICENSE_PRIVATE_KEY_PATH',
      '  - MV3MIGRATE_LICENSE_PRIVATE_KEY',
    ].join('\n'),
  )
}

async function loadPrivateKey(args) {
  if (args.privateKey) return args.privateKey
  if (args.privateKeyPath) {
    const file = await fs.readFile(args.privateKeyPath, 'utf8')
    return file.trim() + '\n'
  }
  const envPath = process.env.MV3MIGRATE_LICENSE_PRIVATE_KEY_PATH
  if (envPath) {
    const file = await fs.readFile(envPath, 'utf8')
    return file.trim() + '\n'
  }
  const inline = process.env.MV3MIGRATE_LICENSE_PRIVATE_KEY
  if (inline) return inline.trim() + '\n'
  throw new Error('Private key not provided.')
}

export async function runLicenseMint(argv, { print = console.log } = {}) {
  const args = parseMintArgs(argv)
  if (args.help) {
    printUsage()
    return { ok: false, exitCode: 0 }
  }

  if (!args.customer) {
    printUsage()
    return { ok: false, exitCode: 1 }
  }

  const privateKeyPem = await loadPrivateKey(args)
  const token = createLicenseToken(
    {
      customer: args.customer,
      plan: resolvePlan(args.plan),
      issuedAt: args.issuedAt,
      expiresAt: args.expiresAt,
      seats: args.seats,
      product: args.product,
    },
    privateKeyPem,
  )

  const payload = {
    customer: args.customer,
    plan: resolvePlan(args.plan),
    issuedAt: args.issuedAt,
    expiresAt: args.expiresAt,
    seats: args.seats,
    product: args.product,
    token,
  }

  if (args.out) {
    const outPath = path.resolve(args.out)
    await fs.writeFile(outPath, `${token}\n`, 'utf8')
    payload.out = outPath
  }

  print(JSON.stringify(payload, null, 2))
  print(token)
  return { ok: true, token, payload }
}

async function main() {
  const result = await runLicenseMint(process.argv.slice(2))
  if (result && !result.ok) {
    process.exit(result.exitCode ?? 1)
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    console.error(error.stack || error.message)
    process.exit(1)
  })
}
