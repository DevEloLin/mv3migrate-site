function parseStringLiterals(value) {
  const matches = [...value.matchAll(/(['"])(.*?)\1/g)]
  return matches.map((match) => match[2])
}

function extractBalancedCall(source, openParenIndex) {
  let depth = 0
  let quote = null
  let escaped = false

  for (let index = openParenIndex; index < source.length; index += 1) {
    const char = source[index]

    if (quote) {
      if (escaped) {
        escaped = false
      } else if (char === '\\') {
        escaped = true
      } else if (char === quote) {
        quote = null
      }
      continue
    }

    if (char === '"' || char === "'" || char === '`') {
      quote = char
      continue
    }

    if (char === '(') depth += 1
    if (char === ')') {
      depth -= 1
      if (depth === 0) {
        return source.slice(openParenIndex + 1, index)
      }
    }
  }

  return null
}

function splitTopLevelArgs(value) {
  const args = []
  let current = ''
  let depth = 0
  let quote = null
  let escaped = false

  for (let index = 0; index < value.length; index += 1) {
    const char = value[index]

    if (quote) {
      current += char
      if (escaped) {
        escaped = false
      } else if (char === '\\') {
        escaped = true
      } else if (char === quote) {
        quote = null
      }
      continue
    }

    if (char === '"' || char === "'" || char === '`') {
      quote = char
      current += char
      continue
    }

    if (char === '(' || char === '[' || char === '{') depth += 1
    if (char === ')' || char === ']' || char === '}') depth -= 1

    if (char === ',' && depth === 0) {
      args.push(current.trim())
      current = ''
      continue
    }

    current += char
  }

  if (current.trim()) args.push(current.trim())
  return args
}

function extractAddListenerCalls(source) {
  const calls = []
  let cursor = 0

  while (cursor < source.length) {
    const listenerIndex = source.indexOf('chrome.webRequest.', cursor)
    if (listenerIndex === -1) break

    const addListenerIndex = source.indexOf('.addListener(', listenerIndex)
    if (addListenerIndex === -1) break

    const openParenIndex = source.indexOf('(', addListenerIndex)
    if (openParenIndex === -1) break

    const callBody = extractBalancedCall(source, openParenIndex)
    if (callBody) calls.push(callBody)

    cursor = openParenIndex + 1
  }

  return calls
}

function extractArrayValues(section) {
  if (!section) return []
  return parseStringLiterals(section)
}

function extractSectionBody(source, sectionName) {
  const regex = new RegExp(`${sectionName}\\s*:\\s*\\[([\\s\\S]*?)\\]`)
  const match = source.match(regex)
  return match?.[1] ?? null
}

function extractHeaderMods(sectionBody) {
  if (!sectionBody) return []
  const matches = [...sectionBody.matchAll(/header\s*:\s*(['"])(.*?)\1[\s\S]{0,120}?operation\s*:\s*(['"])(remove|set|append)\3([\s\S]{0,120}?value\s*:\s*(['"])(.*?)\6)?/g)]
  return matches.map((match) => {
    const header = match[2]?.trim()
    const operation = match[4]
    const value = match[7]
    const item = { header, operation }
    if (operation !== 'remove' && value !== undefined) {
      item.value = value
    }
    return item
  }).filter((item) => item.header)
}

function inferDnrAction(source) {
  const redirectUrlMatch = source.match(/redirectUrl\s*:\s*(['"])(.*?)\1/)
  if (redirectUrlMatch?.[2]) {
    return {
      type: 'redirect',
      redirect: { url: redirectUrlMatch[2] },
      note: 'Redirect inferred from webRequest listener source.',
    }
  }

  const requestHeaders = extractHeaderMods(extractSectionBody(source, 'requestHeaders'))
  const responseHeaders = extractHeaderMods(extractSectionBody(source, 'responseHeaders'))
  if (requestHeaders.length || responseHeaders.length) {
    return {
      type: 'modifyHeaders',
      requestHeaders,
      responseHeaders,
      note: 'Header modifications inferred from webRequest listener source.',
    }
  }

  return {
    type: 'block',
    note: 'Blocking behavior inferred from cancel:true listener source.',
  }
}

function trimSnippet(source, maxLength = 240) {
  const compact = source.replace(/\s+/g, ' ').trim()
  if (compact.length <= maxLength) return compact
  return `${compact.slice(0, maxLength - 1)}…`
}

function globToRegex(glob) {
  if (glob === '<all_urls>') return '.*'
  return `^${glob
    .replaceAll('\\', '\\\\')
    .replaceAll('.', '\\.')
    .replaceAll('+', '\\+')
    .replaceAll('?', '\\?')
    .replaceAll('^', '\\^')
    .replaceAll('$', '\\$')
    .replaceAll('{', '\\{')
    .replaceAll('}', '\\}')
    .replaceAll('(', '\\(')
    .replaceAll(')', '\\)')
    .replaceAll('|', '\\|')
    .replaceAll('[', '\\[')
    .replaceAll(']', '\\]')
    .replaceAll('*', '.*')}$`
}

function buildDnrRules(fileFindings, manifestWarnings) {
  const rules = []
  let nextId = 1

  for (const entry of fileFindings) {
    for (const finding of entry.findings || []) {
      if (finding.code !== 'webRequestBlocking') continue

      const source = entry.source ?? ''
      const calls = extractAddListenerCalls(source)
      const listenerArgs = calls.length ? calls : [source]

      for (const listenerSource of listenerArgs) {
        const urlMatch = listenerSource.match(/urls\s*:\s*\[([\s\S]*?)\]/)
        const rawUrls = urlMatch ? extractArrayValues(urlMatch[1]) : ['<all_urls>']
        const resourceMatch = listenerSource.match(/(?:resourceTypes|types)\s*:\s*\[([\s\S]*?)\]/)
        const resourceTypes = resourceMatch
          ? extractArrayValues(resourceMatch[1])
          : ['main_frame', 'sub_frame', 'xmlhttprequest']
        const action = inferDnrAction(listenerSource)
        const evidence = {
          file: entry.path,
          snippet: trimSnippet(listenerSource),
          urls: rawUrls,
          resourceTypes,
        }

        for (const rawUrl of rawUrls) {
          const rule = {
            id: nextId++,
            priority: 1,
            action: { type: action.type },
            condition: {
              regexFilter: globToRegex(rawUrl),
              resourceTypes,
            },
          }

          if (action.type === 'redirect') {
            rule.action.redirect = action.redirect
          } else if (action.type === 'modifyHeaders') {
            if (action.requestHeaders.length) rule.action.requestHeaders = action.requestHeaders
            if (action.responseHeaders.length) rule.action.responseHeaders = action.responseHeaders
          }

          if (action.note) rule.note = action.note
          rule.evidence = evidence

          rules.push(rule)
        }
      }
    }
  }

  if (!rules.length && manifestWarnings.some((warning) => warning.includes('webRequest'))) {
    rules.push({
      id: 1,
      priority: 1,
      action: { type: 'block' },
      condition: {
        regexFilter: '.*',
        resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest'],
      },
      note: 'Draft generated from manifest warnings only. Inspect listener code for exact scopes.',
    })
  }

  return rules
}

function buildBlockingAdvice(findings, manifestWarnings, fileFindings) {
  const hasBlockingWebRequest = findings.some((finding) => finding.code === 'webRequestBlocking')
  if (!hasBlockingWebRequest) return []

  return [
    {
      code: 'dnr-migration',
      title: 'Blocking webRequest listener detected',
      severity: 'critical',
      recommendation: 'Convert the listener into declarativeNetRequest rules and verify rule priority.',
      nextSteps: [
        'Inspect the generated DNR draft and confirm the match scopes.',
        'Move stable blocking behavior to declarativeNetRequest.',
        'Keep a manual review path for listeners that depend on runtime state.',
      ],
      evidence: manifestWarnings.filter((warning) => warning.includes('webRequest')),
      draftRules: buildDnrRules(fileFindings, manifestWarnings),
    },
  ]
}

export function buildPremiumSuggestions({ fileFindings = [], manifestWarnings = [] }) {
  const findings = fileFindings.flatMap((entry) => entry.findings || [])
  return {
    dnr: buildBlockingAdvice(findings, manifestWarnings, fileFindings),
  }
}
