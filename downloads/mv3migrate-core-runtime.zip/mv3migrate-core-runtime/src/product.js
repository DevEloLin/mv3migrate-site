const FEATURE_TIERS = {
  free: {
    name: 'Free',
    maxInputs: 1,
    premium: false,
    outputs: ['manifest conversion', 'JS scan', 'HTML report'],
  },
  pro: {
    name: 'Pro',
    maxInputs: Infinity,
    premium: true,
    outputs: ['manifest conversion', 'JS scan', 'HTML report', 'batch summary', 'DNR suggestions'],
  },
}

export function resolvePlan(value) {
  const plan = String(value ?? 'free').toLowerCase()
  return FEATURE_TIERS[plan] ? plan : 'free'
}

export function getTier(plan) {
  return FEATURE_TIERS[resolvePlan(plan)]
}

export function hasPremiumAccess(plan) {
  return getTier(plan).premium
}

export function assertPremium(plan, featureName) {
  if (!hasPremiumAccess(plan)) {
    const error = new Error(
      `${featureName} is a paid feature. Upgrade to Pro to unlock batch runs and DNR suggestions.`,
    )
    error.code = 'PAID_FEATURE_REQUIRED'
    throw error
  }
}
